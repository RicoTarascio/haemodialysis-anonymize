from setuptools import setup

setup(
    name="anonymize",
    version="0.1",
    description="A sample Python package",
    author="Federico Tarascio",
    author_email="fe.tarascio@gmail.com",
    packages=["anonymize"],
)
